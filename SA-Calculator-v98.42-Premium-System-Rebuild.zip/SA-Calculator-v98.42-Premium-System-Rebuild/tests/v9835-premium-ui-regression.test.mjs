import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");
const css=read("assets/css/rebuild-v98.35.css");
const html=read("index.html");
const pkg=JSON.parse(read("package.json"));
test("v98.35 touch-focus fix hides the skip-link ghost while keyboard focus remains visible",()=>{
 assert.match(css,/\.skip-to-workspace:focus \{[^}]*opacity:0 !important/);
 assert.match(css,/\.skip-to-workspace:focus-visible \{[^}]*opacity:1 !important/);
 assert.match(css,/focus:not\(:focus-visible\)/);
 assert.match(html,/href="#screen-viewport"/);
});
test("v98.35 premium drawer includes every declared calculator tool exactly once",()=>{
 const menu=[...html.matchAll(/class="drawer-item" data-screen="([^"]+)"/g)].map(m=>m[1]);
 const screens=[...html.matchAll(/id="screen-([^"]+)"/g)].map(m=>m[1]).filter(x=>!['calc','favorites','settings','viewport'].includes(x));
 assert.equal(menu.length,16); assert.equal(new Set(menu).size,menu.length);
 assert.deepEqual([...menu].sort(),[...screens].sort());
 assert.match(html,/assets\/css\/rebuild-v98\.35\.css/);
});
test("v98.35 drawer keeps searchable categorized actions and light-theme contrast",()=>{
 assert.match(html,/id="drawer-tool-search"/); assert.equal((html.match(/class="drawer-category"/g)||[]).length,6);
 assert.match(css,/body\[data-theme="light"\] \.drawer-category/);
 assert.match(css,/\.drawer-category \.drawer-item\.active/);
});
test("v98.35 release identity is synchronized",()=>{assert.equal(pkg.version,"1.98.42-v98.42");});
