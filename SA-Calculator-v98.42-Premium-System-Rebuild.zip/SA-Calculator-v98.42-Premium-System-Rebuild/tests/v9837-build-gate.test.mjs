import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");
test("v98.37 premium stylesheet is required by the Android web-bundle builder",()=>{
 const builder=read("scripts/prepare-android-web.mjs");
 assert.match(builder,/assets\/css\/rebuild-v98\.39\.css/);
 const html=read("index.html"); assert.match(html,/assets\/css\/rebuild-v98\.39\.css/);
 const sw=read("service-worker.js"); assert.match(sw,/assets\/css\/rebuild-v98\.39\.css/);
});
test("v98.37 workflow requires the exact stylesheet before and after web bundling",()=>{
 const workflow=read(".github/workflows/main.yml");
 assert.match(workflow,/assets\/css\/rebuild-v98\.39\.css/);
 assert.match(workflow,/www\/assets\/css\/rebuild-v98\.39\.css/);
 assert.match(read("SA-Calculator-v98.42-Android-Workflow.yml"),/www\/assets\/css\/rebuild-v98\.39\.css/);
});
test("v98.37 stylesheet constrains intrinsic widths across tool forms",()=>{
 const css=read("assets/css/rebuild-v98.37.css");
 assert.match(css,/\.input-row,\s*#screen-viewport[\s\S]*min-width: 0/);
 assert.match(css,/textarea \{ min-width: 0; max-width: 100%; \}/);
});
