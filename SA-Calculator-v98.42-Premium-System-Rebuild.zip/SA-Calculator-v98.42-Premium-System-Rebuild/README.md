# SA Calculator v98.42 — Consolidated premium release

## What changed in v98.42
- Consolidated the existing production CSS cascade into one generated `assets/css/app.css` file. The original source layers remain in `assets/css/` for maintainability and reproducible builds.
- The HTML now loads one production stylesheet instead of nine separate stylesheets, reducing render-blocking stylesheet requests while preserving source order and styling rules.
- The Android web-bundle builder regenerates the consolidated stylesheet from the source layers before copying assets.
- The service worker precaches the consolidated stylesheet rather than caching unused individual CSS layers.
- Corrected release identity to `1.98.42-v98.42` / Android versionCode `1098042`.
- Removed obsolete duplicate root workflow files. One active GitHub Actions workflow remains at `.github/workflows/main.yml`; the downloadable standalone copy is `SA-Calculator-v98.42-Android-Workflow.yml`.
- Preserved existing calculator logic, registered tool screens, converter behavior, themes, settings, history, favorites and scientific dialog behavior.

## Build and test
- `npm test` runs the complete Node regression suite.
- `npm run build:web` regenerates the single CSS bundle and prepares the Capacitor web root.
- `npm run android:apk` builds a debug APK when Android SDK/Gradle prerequisites are available.

## Validation limits
Automated tests and source/bundle checks do not replace hosted GitHub Actions execution, real Android installation, screenshot comparison, touch-latency measurement, memory profiling or long-session device testing. The 18-screen visual reference is a design guide, not a screenshot captured from a running APK.
