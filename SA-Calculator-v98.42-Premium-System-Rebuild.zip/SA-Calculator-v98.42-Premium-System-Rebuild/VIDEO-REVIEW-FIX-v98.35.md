# Android UI review — v98.35

The supplied recording shows a cyan rounded partial outline above Currency Converter and Sales Tax tool headers. Its dimensions and border styling match the `.skip-to-workspace` accessibility link. The previous release exposed it through `:focus` on touch WebView; v98.35 changes visibility to `:focus-visible` and explicitly suppresses touch-only focus.

The recording also shows a compact Quick Guide overlay and 16 categorized tool destinations. The drawer now uses a unified two-column premium card layout, searchable categories, clearer selected state, and explicit light-theme colors.

The tool navigation and calculator logic were preserved. Automated tests validate the fix contract and menu-to-screen completeness; physical device confirmation is still required after installing the rebuilt APK.
